//**************************************************************************/
// Copyright (c) 2023 Autodesk, Inc.
// All rights reserved.
//
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION:  User plugin interface
// AUTHOR: Autodesk Inc.
//**************************************************************************/


#define VRED_USER_PLUGIN_VERSION 100

#include <iostream>
#include <string>
#include <functional>
#include <memory>


#include <cstdint>

namespace VREDGLBufferFlags
{
    const std::uint32_t None =  0;
    const std::uint32_t LeftEye =  1;
    const std::uint32_t RightEye = 2; 
}

extern "C"
{
    struct VREDGLBuffer
    {
        std::uint32_t fboId;
        std::uint32_t glFormat;
        std::uint32_t flags;
        std::uint32_t width;
        std::uint32_t height;
    };
}

class VREDUserPluginInterface;

extern "C"
{
    struct VREDFunctions
    {
        std::uint32_t (*getVersion)();
        void (*setFrameSize)(std::uint32_t width, std::uint32_t height);
        bool (*runPython)(const char *code);
        const char * (*runPythonR)(const char *code);

        using InitCB = void (*)(void *);
        void (*registerInit)(void *instance, InitCB cb);

        using FrameBufferChangedCB = bool (*)(void *, const VREDGLBuffer &);
        void (*registerFrameBufferChanged)(void *instance, FrameBufferChangedCB cb);
    };
}

class VREDUserKernelInterface
{
public:

    VREDUserKernelInterface(const VREDFunctions *kiFunctions) :
        m_kiFunctions(kiFunctions),
        m_initFP(nullptr),
        m_frameBufferChangedFP(nullptr)
    {
    }

    ~VREDUserKernelInterface() = default;

    inline std::uint32_t getVersion() const
    {
        return m_kiFunctions->getVersion();
    }

    inline void setFrameSize(std::uint32_t width, std::uint32_t height)
    {
        m_kiFunctions->setFrameSize(width, height);
    }

    inline bool runPython(const std::string &code)
    {
        return m_kiFunctions->runPython(code.c_str());
    }

    inline std::string runPythonR(const std::string &code)
    {
        return m_kiFunctions->runPythonR(code.c_str());
    }

    inline void registerInit(std::function<void()> fp)
    {
        m_initFP = fp;
        m_kiFunctions->registerInit(this, [](void *self)
        {
            static_cast<VREDUserKernelInterface *>(self)->m_initFP();
        });
    }

    inline void registerFrameBufferChanged(std::function<bool(const VREDGLBuffer &)> fp)
    {
        m_frameBufferChangedFP = fp;
        m_kiFunctions->registerFrameBufferChanged(this, [](void *self, const VREDGLBuffer &context) -> bool
        {
            return static_cast<VREDUserKernelInterface *>(self)->m_frameBufferChangedFP(context);
        });
    }

private:

    const VREDFunctions *m_kiFunctions;
    std::function<void()> m_initFP;
    std::function<bool(const VREDGLBuffer &)> m_frameBufferChangedFP;

};

class VREDUserPluginInterface
{
protected:

    ~VREDUserPluginInterface() = default;

public:

    inline virtual void init() = 0;
};

// *******************************************
// Helper macro for registering a user plugin.
// *******************************************

#ifdef _WIN32
    #define VRED_EXPORT __declspec(dllexport)
#else
    #define VRED_EXPORT
#endif

#ifndef _WIN32
    #define VRED_HIDE __attribute__((visibility ("hidden")))
#else
    #define VRED_HIDE
#endif

template<typename T>
class VRED_HIDE VREDRegisterUserPlugin
{
public:

    VREDRegisterUserPlugin(const VREDFunctions *kiFunctions) :
        m_kernelInterface(kiFunctions),
        m_userPlugin(nullptr)
    {
        if(m_kernelInterface.getVersion() == VRED_USER_PLUGIN_VERSION)
        {
            m_userPlugin = std::make_unique<T>(&m_kernelInterface);
            m_kernelInterface.registerInit([this](){ m_userPlugin->init(); });
        }
        else
        {
            std::cerr << "Registering of vred user plugin " << typeid(T).name() << " failed because of a version mismatch, API uses version " \
                      << VRED_USER_PLUGIN_VERSION << " and the kernel uses version " << m_kernelInterface.getVersion() << std::endl; \
            m_userPlugin = nullptr; \
        }
    }

private:

    VREDUserKernelInterface m_kernelInterface;
    std::unique_ptr<T> m_userPlugin;

};

#define VRED_REGISTER_USER_PLUGIN(className) \
extern "C" \
{ \
    VRED_EXPORT void *createUserPlugin(const VREDFunctions *kiFunctions) \
    { \
        auto userData = new VREDRegisterUserPlugin<className>(kiFunctions); \
        return userData; \
    } \
    VRED_EXPORT void destroyUserPlugin(void *userData) \
    { \
        delete reinterpret_cast<className *>(userData); \
    } \
} 
