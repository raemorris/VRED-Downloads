//**************************************************************************/
// Copyright (c) 2021 Autodesk, Inc.
// All rights reserved.
//
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION:  User plugin interface
// AUTHOR: Autodesk Inc.
//**************************************************************************/

// with the post python setVServerState(1) trick we don't write any images while the scene
// is still loading or not yet rendered!
// VREDCore.exe "E:/amz/src/vred-2024.2/Build/install/examples/Automotive_Genesis.vpb" -postpython "setVServerState(1)"


#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <array>
#include <thread>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <dlfcn.h>
#endif

#include "vrUserPluginDemo.h"

// *********************************
// OpenGL related stuff
// *********************************

#define GL_BGR              0x80E0
#define GL_PACK_ALIGNMENT   0x0D05
#define GL_UNSIGNED_BYTE    0x1401

using GLenum = unsigned int;
using GLint = int;
using GLsizei = int;
using GLvoid = void;

using GLReadPixelsFunc = void (*)(GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, GLvoid *);
static GLReadPixelsFunc glReadPixels = nullptr;

using GLPixelStoreiFunc = void (*)(GLenum, GLint);
static GLPixelStoreiFunc glPixelStorei = nullptr;

static void initGL()
{
#ifdef _WIN32
    auto glLibrary = LoadLibrary("opengl32.dll");
    if(glLibrary == nullptr)
        return;

    glReadPixels = reinterpret_cast<GLReadPixelsFunc>(GetProcAddress(glLibrary, "glReadPixels"));
    glPixelStorei = reinterpret_cast<GLPixelStoreiFunc>(GetProcAddress(glLibrary, "glPixelStorei"));

#else

    auto glLibrary = dlopen("/usr/lib64/libGL.so.1", RTLD_LAZY);
    if(glLibrary == nullptr)
        return;

    glReadPixels = reinterpret_cast<GLReadPixelsFunc>(dlsym(glLibrary, "glReadPixels"));
    glPixelStorei = reinterpret_cast<GLPixelStoreiFunc>(dlsym(glLibrary, "glPixelStorei"));

#endif
}

static bool writeBMP(const std::string &filename, std::uint32_t w, std::uint32_t h, const char *rgb)
{
    std::ofstream out(filename, std::ios_base::out | std::ios_base::binary);
    if(!out)
        return false;

    std::uint32_t pad = w * -3 & 3;
    std::uint32_t total = 54 + 3*w*h + pad*h;
    std::array<uint32_t, 13> head = {total, 0u, 54u, 40u, w, h, (24u<<16u)|1u};

    out.write("BM", 2);
    out.write(reinterpret_cast<const char *>(head.data()), 52);
    for(uint32_t i=0 ; i<h ; i++)
    {   out.write(rgb + (3 * w * i), 3 * w);
        out.write(reinterpret_cast<const char *>(&pad), pad);
    }

    return true;
}

static void writeFrameBuffer(std::uint32_t fboId, std::uint32_t width, std::uint32_t height)
{
    if(glReadPixels == nullptr || glPixelStorei == nullptr)
        return;

    std::vector<char> img;
    img.resize(width * height * 3);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, width, height, GL_BGR, GL_UNSIGNED_BYTE, img.data());

#ifdef _WIN32
    static int count = 0;
    std::string path = "image" + std::to_string(count++) + ".bmp";
    auto appdata = getenv("APPDATA");
    if(appdata != nullptr)
        path = std::string(appdata) + "\\" + path;
#else
    std::string path = "/tmp/image.bmp";
#endif

    if(writeBMP(path, width, height, img.data()))
        std::cout << "*** vrUserPluginDemo::writeFrameBuffer: wrote image to: " << path << std::endl;
}

// *********************************
// Plugin implementation
// *********************************
vrUserPluginDemo::vrUserPluginDemo(VREDUserKernelInterface *kernelInterface) :
    m_ki(kernelInterface),
    m_readyToRender(false),
    m_updateCount(0)
{
    std::cout << "*** vrUserPluginDemo::vrUserPluginDemo" << std::endl;
    m_ki->registerUpdate([this]()
    {
        update();
    });

    m_ki->registerMessage([this](const VREDMessage &msg)
    {
        message(msg);
    });

    m_ki->registerFrameBufferChanged([this](const VREDGLBuffer &context) -> bool
    {
        return frameBufferChanged(context);
    });
}

vrUserPluginDemo::~vrUserPluginDemo()
{
    std::cout << "*** vrUserPluginDemo::~vrUserPluginDemo" << std::endl;
}

void vrUserPluginDemo::init()
{
    initGL();
    std::string cmd = "42 * 12";
    auto r = m_ki->runPythonR(cmd.c_str());
    std::cout << "*** vrUserPluginDemo::init: runPython: '" << cmd << "' returns: " << r << std::endl;
    //m_ki->setFrameSize(1920, 1080);
    std::thread t([this]()
    {
        std::this_thread::sleep_for(std::chrono::seconds(5));
        std::string cmd = "42 * 12";
        auto r = m_ki->runPythonR(cmd.c_str());
        std::cout << "*** vrUserPluginDemo::init: runPython from a thread: '" << cmd << "' returns: " << r << std::endl;
    });
    t.detach();
}

void vrUserPluginDemo::update()
{
    // just print the first 10 times
    if(m_updateCount < 10)
    {
        std::cout << "*** vrUserPluginDemo::update" << std::endl;
        ++m_updateCount;
    }
}

void vrUserPluginDemo::message(const VREDMessage &msg)
{
    //std::cout << "*** vrUserPluginDemo::message: " << msg.type << std::endl;
    if(msg.type == VREDMessageTypes::NewScene)
    {
        m_readyToRender = false;
    }
    else if(msg.type == VREDMessageTypes::ProjectReadyToRender)
    {
        std::cout << "*** vrUserPluginDemo::message: ProjectReadyToRender" << std::endl;
        m_readyToRender = true;
    }
}

bool vrUserPluginDemo::frameBufferChanged(const VREDGLBuffer &context)
{
    if(!m_readyToRender)
        return false;

    writeFrameBuffer(context.fboId, context.width, context.height);
    // return true means don't blit to the vred render window.
    return false;
}

VRED_REGISTER_USER_PLUGIN(vrUserPluginDemo)
