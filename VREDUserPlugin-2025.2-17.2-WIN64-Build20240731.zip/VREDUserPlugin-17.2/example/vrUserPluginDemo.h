//**************************************************************************/
// Copyright (c) 2021 Autodesk, Inc.
// All rights reserved.
//
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION:  User plugin interface
// AUTHOR: Autodesk Inc.
//**************************************************************************/

#pragma once

#include <VREDUserPluginInterface.h>

class vrUserPluginDemo : public VREDUserPluginInterface
{
public:

    vrUserPluginDemo(VREDUserKernelInterface *kernelInterface);
    ~vrUserPluginDemo();

    void init() override;

    void update();
    void message(const VREDMessage &msg);

    bool frameBufferChanged(const VREDGLBuffer &context);

private:

    VREDUserKernelInterface *m_ki;
    bool m_readyToRender;
    std::size_t m_updateCount;
};
