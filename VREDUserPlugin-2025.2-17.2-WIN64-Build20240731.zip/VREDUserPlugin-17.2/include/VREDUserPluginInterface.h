//**************************************************************************/
// Copyright (c) 2024 Autodesk, Inc.
// All rights reserved.
//
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION:  User plugin interface
// AUTHOR: Autodesk Inc.
//**************************************************************************/


#define VRED_USER_PLUGIN_VERSION 110

#include <cstddef>
#include <iostream>
#include <string>
#include <functional>
#include <memory>


#include <cstdint>

namespace VREDGLBufferFlags
{
    const std::uint32_t None =  0;
    const std::uint32_t LeftEye =  1;
    const std::uint32_t RightEye = 2; 
}

namespace VREDMessageTypes
{
    const std::uint32_t None =  0;
    const std::uint32_t PreNewScene = 1;
    const std::uint32_t NewScene =  2;
    const std::uint32_t ProjectLoad =  3;
    const std::uint32_t ProjectLoaded = 4;
    const std::uint32_t ProjectReadyToRender = 5;
    const std::uint32_t PreQuit = 6;
}

extern "C"
{
    struct VREDGLBuffer
    {
        std::uint32_t fboId;
        std::uint32_t glFormat;
        std::uint32_t flags;
        std::uint32_t width;
        std::uint32_t height;
    };

    struct VREDMessage
    {
        std::uint32_t type;
        void *info;
    };
}

class VREDUserPluginInterface;

extern "C"
{
    /**
     * @struct VREDFunctions
     * @brief Structure containing function pointers for VRED plugin operations.
     */
    struct VREDFunctions
    {
        /**
         * @brief Gets the version of the VRED API.
         * @return The version as a 32-bit unsigned integer.
         */
        std::uint32_t (*getVersion)();

        /**
         * @brief Sets the frame size.
         * @param width The width of the frame.
         * @param height The height of the frame.
         */
        void (*setFrameSize)(std::uint32_t width, std::uint32_t height);

        /**
         * @brief Executes a Python command within VRED.
         * @param code The Python code to execute.
         * @return True if the command executed successfully, false otherwise.
         */
        bool (*runPython)(const char *code);

        /**
         * @brief Executes a Python command within VRED and returns the result.
         * @param code The Python code to execute.
         * @return The result of the Python command as a C-string.
         */
        const char * (*runPythonR)(const char *code);

        using InitCB = void (*)(void *);

        /**
         * @brief Registers an initialization callback.
         * @param instance The instance of the plugin.
         * @param cb The callback function to register.
         */
        void (*registerInit)(void *instance, InitCB cb);

        using FrameBufferChangedCB = bool (*)(void *, const VREDGLBuffer &);

        /**
         * @brief Registers a frame buffer changed callback.
         * @param instance The instance of the plugin.
         * @param cb The callback function to register.
         */
        void (*registerFrameBufferChanged)(void *instance, FrameBufferChangedCB cb);

        /**
         * @brief Gets the size of the VRED API. Added in version 110
         * @return The size as a std::size_t.
         */
        std::size_t (*getSize)();

        using UpdateCB = void (*)(void *);

        /**
         * @brief Registers an update callback.
         * @param instance The instance of the plugin.
         * @param cb The callback function to register.
         */
        void (*registerUpdate)(void *instance, UpdateCB cb);

        using MessageCB = void (*)(void *, const VREDMessage &);

        /**
         * @brief Registers a message callback.
         * @param instance The instance of the plugin.
         * @param cb The callback function to register.
         */
        void (*registerMessage)(void *instance, MessageCB cb);
    };
}

class VREDUserKernelInterface
{
public:

    /**
     * @brief Constructor for VREDUserKernelInterface.
     * @param kiFunctions Pointer to the VREDFunctions structure.
     */
    VREDUserKernelInterface(const VREDFunctions *kiFunctions) :
        m_kiFunctions(kiFunctions),
        m_initFP(nullptr),
        m_updateFP(nullptr),
        m_messageFP(nullptr),
        m_frameBufferChangedFP(nullptr)
    {
    }

    /**
     * @brief Destructor for VREDUserKernelInterface.
     */
    ~VREDUserKernelInterface() = default;

    /**
     * @brief Gets the version of the VRED API.
     * @return The version as a 32-bit unsigned integer.
     */
    inline std::uint32_t getVersion() const
    {
        return m_kiFunctions->getVersion();
    }

    /**
     * @brief Gets the size of the VREDFunctions struct in the vred kernel.
     * @return The size as a std::size_t.
     */
    inline std::size_t getSize() const
    {
        // was added in version 110 check if the kernel supports it
        // we can't use offsetof here on getSize directly because this would result in a recursive call to getSize!
        if(getVersion() < 110)
        {
            // calculate the sizeof(VREDFunctions) from version 100
            return (offsetof(VREDFunctions, registerFrameBufferChanged) + sizeof(VREDFunctions::registerFrameBufferChanged));
        }

        return m_kiFunctions->getSize();
    }

    /**
     * @brief Sets the frame size.
     * @param width The width of the frame.
     * @param height The height of the frame.
     */
    inline void setFrameSize(std::uint32_t width, std::uint32_t height)
    {
        m_kiFunctions->setFrameSize(width, height);
    }

    /**
     * @brief Executes a Python command within VRED.
     * @param code The Python code to execute.
     * @return True if the command executed successfully, false otherwise.
     */
    inline bool runPython(const std::string &code)
    {
        return m_kiFunctions->runPython(code.c_str());
    }

    /**
     * @brief Executes a Python command within VRED and returns the result.
     * @param code The Python code to execute.
     * @return The result of the Python command as a std::string.
     */
    inline std::string runPythonR(const std::string &code)
    {
        return m_kiFunctions->runPythonR(code.c_str());
    }

    /**
     * @brief Registers an initialization callback.
     * @param fp The callback function to register.
     */
    inline void registerInit(std::function<void()> fp)
    {
        m_initFP = fp;
        m_kiFunctions->registerInit(this, [](void *self)
        {
            static_cast<VREDUserKernelInterface *>(self)->m_initFP();
        });
    }

    /**
     * @brief Registers an update callback.
     * @param fp The callback function to register.
     */
    inline void registerUpdate(std::function<void()> fp)
    {
        // was added in version 110 check if the kernel supports it
        if(offsetof(VREDFunctions, registerUpdate) >= getSize())
        {
            std::cout << "VREDUserPluginInterface: The kernel does not support the registerUpdate function" << std::endl;
            return;
        }

        m_updateFP = fp;
        m_kiFunctions->registerUpdate(this, [](void *self)
        {
            static_cast<VREDUserKernelInterface *>(self)->m_updateFP();
        });
    }

    /**
     * @brief Registers a message callback.
     * @param fp The callback function to register.
     */
    inline void registerMessage(std::function<void(const VREDMessage &)> fp)
    {
        // was added in version 110 check if the kernel supports it
        if(offsetof(VREDFunctions, registerMessage) >= getSize())
        {
            std::cout << "VREDUserPluginInterface: The kernel does not support the registerMessage function" << std::endl;
            return;
        }

        m_messageFP = fp;
        m_kiFunctions->registerMessage(this, [](void *self, const VREDMessage &msg)
        {
            static_cast<VREDUserKernelInterface *>(self)->m_messageFP(msg);
        });
    }

    /**
     * @brief Registers a frame buffer changed callback.
     * @param fp The callback function to register.
     */
    inline void registerFrameBufferChanged(std::function<bool(const VREDGLBuffer &)> fp)
    {
        m_frameBufferChangedFP = fp;
        m_kiFunctions->registerFrameBufferChanged(this, [](void *self, const VREDGLBuffer &context) -> bool
        {
            return static_cast<VREDUserKernelInterface *>(self)->m_frameBufferChangedFP(context);
        });
    }

private:

    const VREDFunctions *m_kiFunctions;
    std::function<void()> m_initFP;
    std::function<void()> m_updateFP;
    std::function<void(const VREDMessage &)> m_messageFP;
    std::function<bool(const VREDGLBuffer &)> m_frameBufferChangedFP;
};

/**
 * @brief Interface for VRED User Plugin.
 * 
 * This class provides an interface for creating user plugins for VRED.
 */
class VREDUserPluginInterface
{
protected:

    /**
     * @brief Destructor for VREDUserPluginInterface.
     */
    ~VREDUserPluginInterface() = default;

public:

    /**
     * @brief Initializes the user plugin.
     * 
     * This method must be implemented by the user plugin to perform any necessary initialization.
     */
    inline virtual void init() = 0;
};

// *******************************************
// Helper macro for registering a user plugin.
// *******************************************

#ifdef _WIN32
    #define VRED_EXPORT __declspec(dllexport)
#else
    #define VRED_EXPORT
#endif

#ifndef _WIN32
    #define VRED_HIDE __attribute__((visibility ("hidden")))
#else
    #define VRED_HIDE
#endif

/**
 * @brief Template class for registering a user plugin with VRED.
 * 
 * @tparam T The type of the user plugin.
 */
template<typename T>
class VRED_HIDE VREDRegisterUserPlugin
{
public:

    /**
     * @brief Constructor for VREDRegisterUserPlugin.
     * 
     * @param kiFunctions Pointer to the VREDFunctions structure.
     */
    VREDRegisterUserPlugin(const VREDFunctions *kiFunctions) :
        m_kernelInterface(kiFunctions),
        m_userPlugin(nullptr)
    {
        m_userPlugin = std::make_unique<T>(&m_kernelInterface);
        m_kernelInterface.registerInit([this](){ m_userPlugin->init(); });

        if(m_kernelInterface.getVersion() < VRED_USER_PLUGIN_VERSION || m_kernelInterface.getSize() < sizeof(VREDFunctions))
        {
            std::cout << "VREDUserPluginInterface: Registering a vred user plugin " << typeid(T).name() << " compiled for a newer vred kernel version, API uses version "
                      << VRED_USER_PLUGIN_VERSION << " and the vred kernel uses version " << m_kernelInterface.getVersion() << std::endl;
            std::cout << "VREDUserPluginInterface: This can lead to some missing features in the plugin!" << std::endl;
        }
    }

private:

    VREDUserKernelInterface m_kernelInterface; ///< The kernel interface for VRED.
    std::unique_ptr<T> m_userPlugin; ///< The user plugin instance.
};

/**
 * @brief Macro to register a user plugin with VRED.
 * 
 * @param className The name of the user plugin class.
 */
#define VRED_REGISTER_USER_PLUGIN(className) \
extern "C" \
{ \
    VRED_EXPORT void *createUserPlugin(const VREDFunctions *kiFunctions) \
    { \
        auto userData = new VREDRegisterUserPlugin<className>(kiFunctions); \
        return userData; \
    } \
    VRED_EXPORT void destroyUserPlugin(void *userData) \
    { \
        delete reinterpret_cast<className *>(userData); \
    } \
} 
